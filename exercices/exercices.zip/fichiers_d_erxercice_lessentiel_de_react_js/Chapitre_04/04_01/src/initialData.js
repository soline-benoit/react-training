let initialData = [
    {id: 'jsertu7a', name: 'Ranger la vaisselle', completed: false},
    {id: 'jseruo7l', name: 'Répondre appel d\'offres', completed: false},
    {id: 'jseruy2q', name: 'Signer contrat', completed: false},
    {id: 'jserv4sw', name: 'Aspirer le salon', completed: false}
]

export default initialData;